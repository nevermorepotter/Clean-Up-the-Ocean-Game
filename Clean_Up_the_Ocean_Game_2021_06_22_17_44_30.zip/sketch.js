var PLAY = 1;
var END = 0;
var gameState = PLAY;

var superhero, superheroImg;
var theme, themeImg;

var trashGroup, trash1, trash1Img, trash2, trash2Img, trash3, trash3Img;
var life1, life1Img, life2, life2Img, life3, life3Img;
var bombGroup, bomb, bombImg;
var edges;

var score;
var gameOverImg,restartImg

function preload(){
  superheroImg = loadImage("hero.png");
  
  themeImg = loadImage("theme.v1.png");
  
  bombImg = loadImage("bomb.png");
  
  life1Img = loadImage("life.png");
  life2Img = loadImage("life.png");
  life3Img = loadImage("life.png");
  
  trash1Img = loadImage("GlassBottle.png");
  trash2Img = loadImage("PlasticBag.png");
  trash3Img = loadImage("PlasticBottle.png");
  
  restartImg = loadImage("restart_-removebg-preview.png")
  gameOverImg = loadImage("gameover.png")
  
}

function setup() {
  createCanvas(850, 500);
  
  score = 0;
  
  theme = createSprite(15,200,10,10);
  theme.addImage("theme",themeImg);
  theme.x = theme.width/2
  
  superhero = createSprite(130,160,20,50);
  superhero.addImage("superhero",superheroImg);
  superhero.scale = 0.4;
  
  gameOver = createSprite(420,150);
  gameOver.addImage(gameOverImg);
  gameOver.scale = 0.4;
  
  restart = createSprite(420,290);
  restart.addImage(restartImg);
  restart.scale = 0.4;
  
  life1 = createSprite(30,30);
  life1.addImage("life", life1Img);
  life1.scale = 0.1;
  
  life2 = createSprite(70,30);
  life2.addImage("life", life2Img);
  life2.scale = 0.1;
  
  life3 = createSprite(110,30);
  life3.addImage("life", life3Img);
  life3.scale = 0.1;
  
  trashGroup = createGroup();
  bombGroup = createGroup();
}

function draw(){
  background(255);
  
  console.log(score);
  console.log(gameState);
  
  stroke("black");
  strokeWeight(4);
  text("Score: "+ score, 400,100);
  
  theme.depth = score.depth 
  
  if(gameState === PLAY){
 
    gameOver.visible = false;
    restart.visible = false;
    
    edges = createEdgeSprites();
    superhero.bounceOff(edges);
    
    if(keyDown("up_arrow")){
       superhero.y= superhero.y-20;
    }
    
    if(keyDown("down_arrow")){
       superhero.y = superhero.y + 20;
    }
    
    if(trashGroup.isTouching(superhero)){
       score = score + 2;
    }
    
    if(bombGroup.isTouching(superhero)){
       
      gameState = END;
       superhero.velocityY = 0;

      trashGroup.setLifetimeEach(-1);
      bombGroup.setLifetimeEach(-1);
     
     trashGroup.setVelocityXEach(0);
     bombGroup.setVelocityXEach(0);  
    }
  }
  
  //rotateSprite();
  spawnTrash();
  spawnBomb();
  
  drawSprites();
}

function spawnTrash(){
 if (frameCount % 60 === 0){
   var trash = createSprite(850,Math.round(random(60,450)),10,40);
   trash.velocityX = -(6 + score/100);
   
    var rand = Math.round(random(1,3));
    switch(rand) {
      case 1 : trash.addImage(trash1Img);
              break;
      case 2 : trash.addImage(trash2Img);
              break;
      case 3 : trash.addImage(trash3Img);
              break;
      default : break;
    }
         
    trash.scale = 0.2;
    trash.lifetime = 110;

    trashGroup.add(trash);
 }
}

function spawnBomb(){
  if(frameCount % 80 === 0){
    bomb = createSprite(850, Math.round(random(60,450)),10,40);
    bomb.addImage("bomb", bombImg);
    bomb.velocityX = -(6 + score/100);
    bomb.scale = 0.2;
    bomb.lifetime = 200;
    bombGroup.add(bomb);
  }
  
}

//function rotateSprite(superhero){
  //superhero.rotation = superhero.rotation + 10;
//}